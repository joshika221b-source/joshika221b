<div align="center">

<img src="assets/header.svg" width="100%" alt="Joshika M. — Computer Science // Developer in progress"/>

<img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=500&size=19&duration=2800&pause=900&color=FF4FA3&center=true&vCenter=true&width=620&height=40&lines=I+build.;I+break.;I+understand.;I+rebuild.;girls+who+code+write+the+future+%E2%99%A1" alt="Typing animation"/>

![CSE Student](https://img.shields.io/badge/CSE_STUDENT-0D0D12?style=for-the-badge&logo=gnometerminal&logoColor=FF4FA3&labelColor=0D0D12&color=2A1B3D)
![Developer](https://img.shields.io/badge/DEVELOPER-0D0D12?style=for-the-badge&logo=visualstudiocode&logoColor=B9A3FF&labelColor=0D0D12&color=2A1B3D)
![Creative](https://img.shields.io/badge/CREATIVE_THINKER-0D0D12?style=for-the-badge&logo=sparkfun&logoColor=FF4FA3&labelColor=0D0D12&color=2A1B3D)

[![GitHub](https://img.shields.io/badge/GITHUB-FF4FA3?style=for-the-badge&logo=github&logoColor=0D0D12)](https://github.com/joshika221b)
[![Projects](https://img.shields.io/badge/PROJECTS-B9A3FF?style=for-the-badge&logo=github&logoColor=0D0D12)](https://github.com/joshika221b?tab=repositories)

<img src="assets/divider.svg" width="100%" alt=""/>

</div>

## `01 / PROFILE.EXE` ♡

<table>
<tr>
<td width="48%" align="center" valign="middle">
<img src="assets/pixel-girl.svg" width="100%" alt="Pixel art of a girl coding at her desk"/>
</td>
<td valign="top">

```bash
joshika@mainframe:~$ whoami
> Joshika M. — CS student, developer

joshika@mainframe:~$ cat about.txt
> I like understanding how things work,
> experimenting with ideas, and turning
> what I learn into projects.
```

- `01` ✦ Building projects and sharpening my programming skills
- `02` ✦ Exploring frontend development and software engineering
- `03` ✦ Practising data structures, algorithms and problem-solving
- `04` ✦ Always curious about what I can build next

> **F.A.I.L.** = **F**irst **A**ttempt **I**n **L**earning.
> Every `ERROR` is the compiler telling me where to grow next. ♡

</td>
</tr>
</table>

<div align="center"><img src="assets/divider.svg" width="100%" alt=""/></div>

## `02 / TECH_STACK` ⌨

<div align="center">

<img src="assets/stack.svg" width="100%" alt="C, C++, Java, HTML5, CSS3, JavaScript, Git, GitHub, VS Code"/>

</div>

<div align="center"><img src="assets/divider.svg" width="100%" alt=""/></div>

## `03 / SELECTED_WORK` ✦

*Every card is wired to its project: QR modules flicker as a code generates, the chess pieces play `1. e4 e5`, the converter cycles through units, and the cube spins.*

<table>
<tr>
<td width="50%" align="center">
<a href="https://joshika221b-source.github.io/QR-generator/"><img src="assets/card-qr.svg" width="100%" alt="QR Studio — QR code generator"/></a>
</td>
<td width="50%" align="center">
<a href="https://github.com/joshika221b/Chess-Game"><img src="assets/card-chess.svg" width="100%" alt="Chess Game — game logic and gameplay"/></a>
</td>
</tr>
<tr>
<td width="50%" align="center">
<a href="https://joshika221b-source.github.io/simple-converter/simple%20converter/"><img src="assets/card-converter.svg" width="100%" alt="Simple Converter — unit conversions"/></a>
</td>
<td width="50%" align="center">
<img src="assets/card-3d.svg" width="100%" alt="3D Renderer — C++ graphics on Windows"/>
</td>
</tr>
</table>

<div align="center"><img src="assets/divider.svg" width="100%" alt=""/></div>

## `04 / CURRENTLY.EXE` ⚡

<div align="center">

<img src="assets/terminal.svg" width="100%" alt="Terminal showing what I'm learning: DSA, frontend engineering, personal projects, problem solving"/>

</div>

<div align="center"><img src="assets/divider.svg" width="100%" alt=""/></div>

## `05 / STATS.LOG` ▣

<div align="center">

<img height="165" src="https://github-readme-stats.vercel.app/api?username=joshika221b&show_icons=true&hide_border=true&bg_color=0D0D12&title_color=FF4FA3&text_color=F4F0FF&icon_color=B9A3FF&ring_color=FF4FA3&count_private=true" alt="GitHub stats"/>
<img height="165" src="https://github-readme-stats.vercel.app/api/top-langs/?username=joshika221b&layout=compact&hide_border=true&bg_color=0D0D12&title_color=FF4FA3&text_color=F4F0FF" alt="Top languages"/>

<img src="https://streak-stats.demolab.com/?user=joshika221b&hide_border=true&background=0D0D12&stroke=2A1B3D&ring=FF4FA3&fire=FF4FA3&currStreakNum=F4F0FF&currStreakLabel=FF4FA3&sideNums=F4F0FF&sideLabels=B9A3FF&dates=9B7BFF" alt="GitHub streak"/>

<img width="100%" src="https://github-readme-activity-graph.vercel.app/graph?username=joshika221b&bg_color=0D0D12&color=B9A3FF&line=FF4FA3&point=F4F0FF&area=true&area_color=FF4FA3&hide_border=true" alt="Contribution graph"/>

<img width="100%" src="https://raw.githubusercontent.com/joshika221b/joshika221b/output/github-snake-dark.svg" alt="Contribution snake"/>

</div>

<div align="center"><img src="assets/divider.svg" width="100%" alt=""/></div>

## `06 / OFFLINE_MODE` ✿

```text
> shutting down the terminal...
> loading: Bharatanatyam · reading · discovering new things
```

Beyond the screen, I enjoy **Bharatanatyam, reading, and discovering new things.**

Different interests. Different perspectives. More ideas to bring back to the screen. ♡

<div align="center">

```
 ┌────────────────────────────────────────────┐
 │  ERROR 404: "give up" not found.           │
 │  Retrying with more curiosity...           │
 └────────────────────────────────────────────┘
```

`DESIGNED BY CURIOSITY. BUILT ONE COMMIT AT A TIME.` ♡

<img src="https://komarev.com/ghpvc/?username=joshika221b&style=for-the-badge&color=FF4FA3&labelColor=0D0D12&label=PROFILE+VISITS" alt="Profile visit counter"/>

<img width="100%" src="https://capsule-render.vercel.app/api?type=waving&height=110&color=0D0D12&section=footer&animation=twinkling" alt=""/>

</div>
